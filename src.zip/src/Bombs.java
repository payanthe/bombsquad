/**
 * Created by parsa on 11/28/2016.
 */
public abstract class Bombs extends GraphicItem {
    public int bombX;
    public int bombY;
    public int direct;
}
