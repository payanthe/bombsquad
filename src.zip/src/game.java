import javax.swing.*;

/**
 * Created by parsa on 11/30/2016.
 */
public class game extends JFrame{
    static Players p1 = new Players();
    static Players p2 = new Players();
    public int[][] plan = new int[20][20];


    public static void main(String[] args) {
        JFrame jFrame=new JFrame("sample frame");
        jFrame.setSize(300,400);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);



        Move move1=new Move(p1);
        Move move2=new Move(p2);
        jFrame.addKeyListener(move1);

    }





    private int turn;

    {
        p1.posX = 18;
        p1.posY = 2;
        p2.posX = 2;
        p2.posY = 18;
        p1.controller=1;
        p2.controller=2;

        for (int i = 0; i < 20; i++) {
            for (int j = 0; j < 20; j++) {
                this.plan[i][j] = 0;
            }
        }

        for (int i = 0; i < 20; i++) {
            plan[i][0] = 0;
            plan[0][i] = 0;
            plan[19][i] = 0;
            plan[i][19] = 0;
        }

        for (int i = 3; i <= 16; i++) {
            plan[i][3] = -600;
            plan[i][4] = -600;
            plan[i][7] = -600;
            plan[i][8] = -600;
            plan[i][11] = -600;
            plan[i][12] = -600;
            plan[i][15] = -600;
            plan[i][16] = -600;



        }
    }

    public boolean winner(Players p) {
        if(p.life<=0){
            return false;
        }
        return true;
    }
}

