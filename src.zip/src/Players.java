/**
 * Created by parsa on 11/28/2016.
 */
public class Players extends GraphicItem {
    public int life = 600;
    public boolean turnAccess = true;
    public int posX;
    public int posY;
    public int direct;
    public int controller;

    public int kindBomb;

    public void checkHouse() {
        if (plan[posX][posY]==10){
            kindBomb=10;
            plan[posX][posY]=0;
        }
        if (plan[posX][posY]==20){
            kindBomb=20;
            plan[posX][posY]=0;
        }
        if (plan[posX][posY]==30){
            kindBomb=30;
            plan[posX][posY]=0;
        }
        if (plan[posX][posY]==40){
            kindBomb=40;
            plan[posX][posY]=0;
        }
        if (plan[posX][posY]<0){
            life+=plan[posX][posY];
        }

    }

    public void pushBomb() {
    }
}
