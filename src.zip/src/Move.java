import javax.swing.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Created by parsa on 11/28/2016.
 */
public class Move implements KeyListener{




    public Move(Players p) {
        int key =0;
        if (p.controller==2) {
            if (key == key) {
                p.posX++;
                p.direct = 1;
            }
            if (key == key) {
                p.posX++;
                p.direct = 2;
            }
            if (key == key) {
                p.posX++;
                p.direct = 3;
            }
            if (key == key) {
                p.posX++;
                p.direct = 4;
            }
        }
        else {





            if (key == key) {
                p.posX++;
                p.direct = 1;
            }
            if (key == key) {
                p.posX++;
                p.direct = 2;
            }
            if (key == key) {
                p.posX++;
                p.direct = 3;
            }
            if (key == key) {
                p.posX++;
                p.direct = 4;
            }
        }

    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

        if (e.getKeyCode() == KeyEvent.VK_RIGHT ) {
            System.out.println("Right pressed.");
            //p.posX++;
            //p.direct = 4;

        }
        else if (e.getKeyCode() == KeyEvent.VK_LEFT ) {
            System.out.println("Left pressed.");
        }
        else if (e.getKeyCode() == KeyEvent.VK_UP ) {
            System.out.println("Up pressed.");
        }
        else if (e.getKeyCode() == KeyEvent.VK_DOWN ) {
            System.out.println("Down pressed.");
        }
        else{
            System.out.println("Key pressed: " + e.getKeyChar());
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

}
